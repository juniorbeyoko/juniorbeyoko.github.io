# juniorbeyoko.com

Official static site for Junior Beyoko.

## Deploy

1. Push this repo to GitHub.
2. Enable GitHub Pages from the repo settings.
3. Your site will be live at https://juniorbeyoko.github.io/
